# Donovan Hawkins
# Date: 11/10/2025
# Assignment: P4LAB1 - Part A (Turtle Graphics: Shapes)
# This program uses turtle graphics and loops to draw a square and a triangle.

import turtle

# Create turtle object
t = turtle.Turtle()
t.pensize(3)
t.color("blue")

# Draw a square using a for loop
for i in range(4):
    t.forward(100)
    t.right(90)

# Move turtle before drawing the triangle
t.penup()
t.goto(-150, 0)
t.pendown()
t.color("green")

# Draw a triangle using a for loop
for i in range(3):
    t.forward(100)
    t.left(120)

# Keep window open until clicked
turtle.done()
