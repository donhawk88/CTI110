# Donovan Hawkins
# Date: 11/11/2025
# Assignment: P4LAB1 - Part B (Turtle Graphics: Initials)
# This program uses turtle graphics and loops to draw my initials: D.H.

import turtle

t = turtle.Turtle()
t.pensize(4)
t.color("purple")

# Draw the letter D
t.penup()
t.goto(-150, 0)
t.pendown()
t.left(90)
t.forward(100)
t.right(90)

for i in range(18):  # Curve for the "D"
    t.forward(10)
    t.right(10)

# Draw the letter H
t.penup()
t.goto(50, 0)
t.setheading(90)
t.pendown()
t.forward(100)
t.backward(50)
t.right(90)
t.forward(50)
t.left(90)
t.forward(50)
t.backward(100)

t.hideturtle()
turtle.done()
